<?php
require_once 'registration.php';


$validation_msg = "";

$fail = " ";


$username  = $password  =  $email  = "";

 
 if (isset ($_POST['username']))
	 $username = mysqli_real_escape_string($conn, $_POST['username']);
	 $username = filter_var($username, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
 
 
 if (isset ($_POST['password']))
	 $password = mysqli_real_escape_string($conn, $_POST['password']);
	 $password = filter_var($password, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
	 
 
	 
 if (isset ($_POST['email']))
	 $email = mysqli_real_escape_string($conn, $_POST['email']);
	 $email = filter_var($email, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
	 
	 
	 
 
 
$fail  = validate_username($username);
$fail .= validate_password($password);
$fail .= validate_email($email);


 
echo "<!DOCTYPE html >\n<html><head><title>An Example Form</title>";
 
if ($fail == "" )
{
	echo "</head><body>Email or Password already exists
	$username, $password, $email. </body></html>";
	$password = password_hash($password, PASSWORD_BCRYPT);
	$sql= "INSERT INTO userdb VALUES (NULL, '$username', '$email', '$password')";
    $result = $conn->query($sql);

     if (!$result) die ("fatal Eror");{
	 header("location:successfulRegisted.html");}
	
	
}

else{
	$validation_msg = $fail;
}


function validate_username($field)
{
	if ($field == "") return "No Username was entered<br>";
	else if (strlen ($field) < 5)
		return "Username must be at least 5 characters<br>";
	else if (preg_match("/[^a-zA-Z0-9_-]/", $field))
		return "Only letters, numbers, - and _ in username<br>";

}

function validate_password($field)
{
	if ($field == "") 
		return "No Password was entered<br>";
	else if (!preg_match("/[a-z]/", $field) || !preg_match("/[A-Z]/", $field) || !preg_match("/[0-9]/", $field))
		return "Password require 1 of a-z, A-Z and 0-9<br>";
	return "";
}

function validate_email($field)
{
	if($field == "")
		return "No Email was entered<br>";
	else if (!((strpos($field, ".") > 0) && (strpos($field, "@") > 0)) || preg_match("/[^a-zA-Z0-9.@_-]/", $field))
		return "The Email address in invalid<br>";
	return "";	
}

function fix_string($string)
{
	if (get_magic_quotes_gpc()) $string = stripslashes($string);
	return htmlentities($string);
}
         
		 

		  
		 
			
?>


			
<html>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=1920, maximum-scale=1.0" />
    <link rel="shortcut icon" type="image/png" />
    <meta name="og:type" content="website" />
    <meta name="twitter:card" content="photo" />
    <link rel="stylesheet" type="text/css" href="css/artboard-1.css" />
    <link rel="stylesheet" type="text/css" href="css/styleguide.css" />
    <link rel="stylesheet" type="text/css" href="css/globals.css" />
    <script type='text/javascript' src='jquery.min.js'></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </head>
	<style>
		
		.error{
			display: none;
			margin-left: 10px;
		}		
		
		.error_show{
			color: red;
			margin-left: 10px;
		}
		
		input.invalid, textarea.invalid{
			border: 2px solid red;
		}
		
		input.valid, textarea.valid{
			border: 2px solid green;
		}
	</style>
  
 
  
  <script>
		$(document).ready(function() {
			<!-- Real-time Validation -->
				<!--Name can't be blank-->
				$('#u_name').on('input', function() {
					var input=$(this);
					var is_name=input.val();
					if(is_name){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				
				<!--Email must be an email -->
				$('#u_email').on('input', function() {
					var input=$(this);
					var re = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
					var is_email=re.test(input.val());
					if(is_email){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				
			
				$('#u_pass').on('input', function() {
					var input=$(this);
					var re = /((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,})$/;
					var is_pass=re.test(input.val());
					if(is_pass){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				
				
				
		
			<!-- After Form Submitted Validation-->
			$("#user_submit button").click(function(event){
				var form_data=$("#user").serializeArray();
				var error_free=true;
				for (var input in form_data){
					var element=$("#user_"+form_data[input]['name']);
					var valid=element.hasClass("valid");
					var error_element=$("span", element.parent());
					if (!valid){error_element.removeClass("error").addClass("error_show"); error_free=false;}
					else{error_element.removeClass("error_show").addClass("error");}
				}
				if (!error_free){
					event.preventDefault(); 
				}
				else{
					alert('No errors: Form will be submitted');
				}
			});
			
			
			
		});
	</script>
 
  
  <body style="margin: 0; background: #ffffff">
    <input type="hidden" id="anPageName" name="page" value="artboard-1" />
    <div class="container-center-horizontal">
      <div class="artboard-1 screen">
        <div class="overlap-group-C61RwL">
          <img class="base-4eduM0" src="img/base-1@1x.png" />
          <div class="group-28-4eduM0">
            <div class="group-3-UhvxFO">
              <img class="rectangle-1097-NvQKFK" src="img/rectangle-1097-1@1x.png" />
              <img class="rectangle-1098-NvQKFK" src="img/rectangle-1097@1x.png" />
              <img class="rectangle-1099-NvQKFK" src="img/rectangle-1099-1@1x.png" />
              <img class="rectangle-1100-NvQKFK" src="img/rectangle-1100-1@1x.png" />
              <div class="rectangle-1101-NvQKFK"></div>
            </div>
            <div style= "font-family: Lucida Console, Courier New, monospace" class="am-UhvxFO poorrichard-regular-normal-bush-65px">A&amp;M</div></style>
          </div>
          <div class="group-31-4eduM0">
            
          </div>
        </div>
        <div class="flex-row-C61RwL">
          <div class="shopping-e-comm-ashion-purchase-dXBp89">
            <div class="group-xNJQyF">
              <img class="path-epZBxw" src="img/path@1x.png" />
              <div class="oval-epZBxw"></div>
              <div class="oval-SK1AvW"></div>
              <div class="group-epZBxw">
                <div class="flex-col-KKbCiR">
                  <img class="path-ArPwGR" src="img/path-38@1x.png" />
                  <img class="path-QCErMK" src="img/path-39@1x.png" />
                </div>
                <div class="flex-col-itqei9">
                  <img class="path-eSJaSu" src="img/path-37@1x.png" />
                  <img class="path-TwWQst" src="img/path-35@1x.png" />
                </div>
              </div>
              <img class="path-SK1AvW" src="img/path-4@1x.png" />
              <div class="group-SK1AvW">
                <img class="path-8AVmer" src="img/path-40@1x.png" />
                <div class="overlap-group3-8AVmer">
                  <div class="rectangle-Jtifi9"></div>
                  <img class="path-Jtifi9" src="img/path-41@1x.png" />
                </div>
              </div>
              <div class="oval-J5G4fQ"></div>
              <img class="path-J5G4fQ" src="img/path-5@1x.png" />
              <img class="path-3WDIep" src="img/path-7@1x.png" />
              <img class="path-ghsmlM" src="img/path-8@1x.png" />
              <img class="path-Zq0TLb" src="img/path-9@1x.png" />
              <img class="path-DIY5NC" src="img/path-11@1x.png" />
              <div class="group-J5G4fQ">
                <div class="flex-col-ZHC2Ju">
                  <div class="rectangle-BkSCot"></div>
                  <div class="rectangle-9Q1f4j"></div>
                  <div class="rectangle-mzOjQW"></div>
                </div>
                <div class="flex-col-DO56so">
                  <div class="rectangle-RvzZzf"></div>
                  <div class="rectangle-aTh6zT"></div>
                  <div class="rectangle-IBS6WR"></div>
                </div>
                <div class="flex-col-3xcdr4">
                  <div class="rectangle-nFXU87"></div>
                  <div class="rectangle-aiqx3v"></div>
                  <div class="rectangle-gEvO0H"></div>
                </div>
              </div>
              <img class="path-2aRdX8" src="img/path-12@1x.png" />
              <img class="path-RRl9mS" src="img/path-13@1x.png" />
              <img class="path-EixOxO" src="img/path-14@1x.png" />
              <div class="rectangle-epZBxw"></div>
              <img class="path-xwu4zG" src="img/path-15@1x.png" />
              <img class="path-q3HnoQ" src="img/path-16@1x.png" />
              <img class="path-bq0t4H" src="img/path-17@1x.png" />
              <img class="path-xS0g3d" src="img/path-18@1x.png" />
              <div class="group-3WDIep">
                <img class="path-KUWnp0" src="img/path-42@1x.png" />
                <div class="flex-row-KUWnp0">
                  <img class="path-PKGwyK" src="img/path-43@1x.png" />
                  <div class="rectangle-PKGwyK"></div>
                </div>
              </div>
              <img class="group-ghsmlM" src="img/group@1x.png" />
              <img class="path-ZSpVaZ" src="img/path-19@1x.png" />
              <div class="group-Zq0TLb">
                <img class="shape-GpePZG" src="img/path-45@1x.png" />
                <img class="shape-Kxuqvw" src="img/path-47@1x.png" />
                <img class="path-GpePZG" src="img/path-44@1x.png" />
              </div>
              <img class="path-28xD3K" src="img/path-20@1x.png" />
              <img class="path-KL4bbU" src="img/path-21@1x.png" />
              <img class="path-TGPiqV" src="img/path-22@1x.png" />
              <div class="group-DIY5NC">
                <div class="group-UmUxsc">
                  <div class="group-fRl8hQ">
                    <img class="path-dE3uok" src="img/path-50@1x.png" />
                    <div class="overlap-group3-dE3uok">
                      <img class="path-Wu5RDx" src="img/path-51@1x.png" />
                      <img class="path-A10QkR" src="img/path-52@1x.png" />
                    </div>
                    <img class="path-wZYclb" src="img/path-53@1x.png" />
                  </div>
                  <div class="group-wWLJjb">
                    <div class="overlap-group5-YOS57n">
                      <img class="path-o0cckq" src="img/path-55@1x.png" />
                      <img class="path-9112yn" src="img/path-57@1x.png" />
                    </div>
                    <div class="overlap-group4-YOS57n">
                      <img class="path-MB1SUr" src="img/path-54@1x.png" />
                      <img class="path-RrLT0v" src="img/path-56@1x.png" />
                    </div>
                  </div>
                </div>
                <img class="path-UmUxsc" src="img/path-49@1x.png" />
              </div>
              <img class="path-paVaxR" src="img/path-23@1x.png" />
              <img class="path-xavKok" src="img/path-24@1x.png" />
              <div class="group-2aRdX8">
                <img class="path-Wx66WS" src="img/path-49@1x.png" />
                <div class="group-Wx66WS">
                  <img class="path-nxwdL0" src="img/path-59@1x.png" />
                  <img class="path-gxjhHj" src="img/path-60@1x.png" />
                  <div class="group-nxwdL0">
                    <img class="path-4NK29s" src="img/path-65@1x.png" />
                    <div class="flex-row-4NK29s">
                      <div class="overlap-group4-OAp5jd">
                        <img class="path-idYxYM" src="img/path-70@1x.png" />
                        <img class="path-jcjimr" src="img/path-71@1x.png" />
                        <img class="path-PrxiJC" src="img/path-72@1x.png" />
                      </div>
                      <div class="overlap-group3-OAp5jd">
                        <img class="path-1Nd7QS" src="img/path-66@1x.png" />
                        <img class="path-uo6DlH" src="img/path-67@1x.png" />
                        <img class="path-EtGkGU" src="img/path-68@1x.png" />
                        <img class="path-bzMveI" src="img/path-69@1x.png" />
                      </div>
                    </div>
                  </div>
                  <img class="path-xZXm2T" src="img/path-61@1x.png" />
                  <div class="group-gxjhHj">
                    <div class="flex-col-UTA9mN">
                      <img class="path-6pYiJf" src="img/path-73@1x.png" />
                      <img class="path-6WUC4q" src="img/path-75@1x.png" />
                    </div>
                    <div class="flex-col-CUP7h3">
                      <img class="path-xdU3Sv" src="img/path-74@1x.png" />
                      <img class="path-4rZIb5" src="img/path-76@1x.png" />
                    </div>
                  </div>
                  <img class="path-5zDqHV" src="img/path-62@1x.png" />
                  <img class="path-xKJ1Gx" src="img/path-63@1x.png" />
                  <img class="path-6lcEYy" src="img/path-64@1x.png" />
                  <div class="group-xZXm2T">
                    <div class="oval-lAyIP0"></div>
                    <div class="oval-3DrxFu"></div>
                  </div>
                </div>
              </div>
              <img class="path-PQZbFw" src="img/path-25@1x.png" />
              <img class="path-tEsWVp" src="img/path-26@1x.png" />
              <img class="path-m8qNG5" src="img/path-27@1x.png" />
              <img class="path-rej1WB" src="img/path-28@1x.png" />
              <img class="path-mplxSi" src="img/path-29@1x.png" />
              <img class="path-MCBAaC" src="img/path-30@1x.png" />
              <img class="path-rFTc2o" src="img/path-31@1x.png" />
              <div class="oval-3WDIep"></div>
              <div class="oval-ghsmlM"></div>
              <img class="path-Y5yho5" src="img/path-32@1x.png" />
              <img class="path-NLumn8" src="img/path-33@1x.png" />
              <div class="group-RRl9mS">
                <div class="group-CCiVfX">
                  <div class="overlap-group3-UcaS4t">
                    <img class="path-io6ej7" src="img/path-77@1x.png" />
                    <img class="path-faIwdp" src="img/path-78@1x.png" />
                  </div>
                  <img class="path-UcaS4t" src="img/path-79@1x.png" />
                </div>
                <div class="group-nU38sE">
                  <img class="group-8sdvH5" src="img/group-1@1x.png" />
                  <img class="path-8sdvH5" src="img/path-80@1x.png" />
                </div>
              </div>
              <img class="path-5RdR5R" src="img/path-34@1x.png" />
            </div>
          </div>
          <div class="overlap-group2-dXBp89">
            <div class="rectangle-51-zUA2mT"></div>

			<form method = "POST" id="" action="artboard-1.php" >
		    <form>
            <div class="form-zUA2mT">
			
			
              <div class="overlap-group3-xutMw0">
			  
              
                <div class="your-name-TTA3lD">
				<span id='iText'>
				<input class="rectangle-55-TTA3lD border-3px-bush" style="font-family: Futura, 'Trebuchet MS', Arial, sans-serif; font-size: 24px; text-align: center; font-weight: bold; display: block;" id= "u_name" type="username" name= "username" placeholder="Enter your UserName" required /></span>
             			<span class="error">This field is required</span>
				    
				      </div>
              </div>
              <div class="overlap-group4-xutMw0">
                <div ></div>
                <div class="your-email-19LoZd arial-bold-black-24px">
				<input  class="rectangle-55-19LoZd border-3px-bush" style="font-family: Futura, 'Trebuchet MS', Arial, sans-serif; font-size: 24px;text-align: center;font-weight: bold;display: block;" id = "u_email" type="email" name= "email" placeholder="Enter your Email" required />
				<span class="error">This field is required</span>
				</div>
				    </div>
				<div class="overlap-group5-xutMw0">
                <div></div>
                <div>
				<input class="rectangle-55-OykgDa border-3px-bush" style="font-family: Futura, 'Trebuchet MS', Arial, sans-serif; font-size: 24px;text-align: center;font-weight: bold;display: block;" id = "u_pass" type ="password"name="password" placeholder="Enter your Password" required />
				<span class="error">This field is required</span>
				</div>
              </div>
			  <br></br><br></br>
              <input type ="submit"  value="Create an account" class="button-xutMw0" />
			  </div>
			  
            <div class="sign-up-zUA2mT arial-bold-bush-40px">Sign Up</div>
            <div class="already-have-an-account-sign-in-zUA2mT">
			<span style= "font-family: Arial, Helvetica, sans-serif; font-size: 17px;color:red;"><?php   echo  $validation_msg ?> </span>
            <br><span class="span0-7Ow58X">Already have an account? </span><a href = "artboard-2.php"><span class="span1-7Ow58X" style="color:purple">SignIn</span></a>
			  </br>
			 
            </div>
						
			</form>
			
			
			
          </div>
          <a href="artboard-2.html">
            <div class="communication-s-gs-message-text-dXBp89">
              <div class="group-OUs5kD">
                <div class="group-486fCs">
                  <div class="overlap-group3-HlvM2s">
                    <img class="path-bx5IG3" src="img/path-89@1x.png" />
                    <div class="group-bx5IG3">
                      <img class="path-1HbWm7" src="img/path-100@1x.png" />
                      <img class="path-n5Kman" src="img/path-100@1x.png" />
                      <img class="path-6wsfjM" src="img/path-100@1x.png" />
                    </div>
                    <div class="group-qUjkKV">
                      <img class="path-6s1rAW" src="img/path-100@1x.png" />
                      <img class="path-hDOJdl" src="img/path-100@1x.png" />
                      <img class="path-TtOI3x" src="img/path-100@1x.png" />
                    </div>
                    <div class="group-031fNW">
                      <img class="path-EpMtvE" src="img/path-100@1x.png" />
                      <img class="path-QYQL19" src="img/path-100@1x.png" />
                      <img class="path-Z7jJac" src="img/path-100@1x.png" />
                    </div>
                    <div class="group-RCplQG">
                      <img class="path-Hvq04T" src="img/path-100@1x.png" />
                      <img class="path-l9QH2q" src="img/path-100@1x.png" />
                      <img class="path-O95zjk" src="img/path-100@1x.png" />
                    </div>
                  </div>
                  <img class="path-HlvM2s" src="img/path-90@1x.png" />
                </div>
                <div class="group-I6CGAw">
                  <div class="flex-col-GDa4jo">
                    <img class="shape-K1ShwC" src="img/path-103@1x.png" />
                    <img class="shape-NapuGR" src="img/path-103@1x.png" />
                    <img class="shape-vo1e21" src="img/path-103@1x.png" />
                    <img class="shape-19gYxE" src="img/path-139@1x.png" />
                    <img class="shape-tkJnnq" src="img/path-103@1x.png" />
                  </div>
                  <div class="flex-col-obGiHL">
                    <img class="shape-YGzgQ9" src="img/shape-11@1x.png" />
                    <img class="shape-bCUHCq" src="img/shape-11@1x.png" />
                    <img class="shape-YOdm12" src="img/shape-11@1x.png" />
                    <img class="shape-SlxDw9" src="img/shape-15@1x.png" />
                    <img class="shape-IjdNJ1" src="img/shape-11@1x.png" />
                  </div>
                  <div class="flex-col-LPnVsP">
                    <img class="shape-VzMCPq" src="img/shape-11@1x.png" />
                    <img class="shape-WASYHn" src="img/shape-11@1x.png" />
                    <img class="shape-q6whsg" src="img/shape-11@1x.png" />
                    <img class="shape-kXxs66" src="img/shape-15@1x.png" />
                    <img class="shape-PNBvxB" src="img/shape-11@1x.png" />
                  </div>
                  <div class="flex-col-rxf6HX">
                    <img class="shape-sqtU5Z" src="img/shape-11@1x.png" />
                    <img class="shape-2DPWwY" src="img/shape-11@1x.png" />
                    <img class="shape-1VYxIx" src="img/shape-11@1x.png" />
                    <img class="shape-m7r49u" src="img/shape-15@1x.png" />
                    <img class="shape-ogtwlY" src="img/shape-11@1x.png" />
                  </div>
                </div>
                <div class="group-x023y0">
                  <img class="path-M1A4OE" src="img/path-164@1x.png" />
                  <div class="overlap-group4-M1A4OE">
                    <img class="path-b4Fi8k" src="img/path-163@1x.png" />
                    <div class="group-b4Fi8k">
                      <img class="path-F6L5i1" src="img/path-165@1x.png" />
                      <img class="path-6B7Smw" src="img/path-165@1x.png" />
                      <img class="path-ynmwx8" src="img/path-165@1x.png" />
                    </div>
                    <div class="group-9nDJwZ">
                      <img class="path-aPYu2B" src="img/path-165@1x.png" />
                      <img class="path-ufO8ah" src="img/path-165@1x.png" />
                      <img class="path-0cySwF" src="img/path-165@1x.png" />
                    </div>
                    <div class="group-jDnbad">
                      <img class="path-RxnlGP" src="img/path-165@1x.png" />
                      <img class="path-GPxR9t" src="img/path-165@1x.png" />
                      <img class="path-H1rLgd" src="img/path-165@1x.png" />
                    </div>
                    <div class="group-e7ReiT">
                      <img class="path-aiTiHB" src="img/path-165@1x.png" />
                      <img class="path-rT5i9E" src="img/path-165@1x.png" />
                      <img class="path-877E33" src="img/path-165@1x.png" />
                    </div>
                  </div>
                </div>
                <div class="group-n7RHNx">
                  <div class="flex-col-78Y6tf">
                    <img class="shape-Lx9yxt" src="img/shape-22@1x.png" />
                    <img class="shape-iL9YLT" src="img/shape-26@1x.png" />
                    <img class="shape-DBlekm" src="img/shape-22@1x.png" />
                    <img class="shape-SojAfa" src="img/shape-22@1x.png" />
                    <img class="shape-ANLoRm" src="img/shape-22@1x.png" />
                  </div>
                  <div class="flex-col-Z4Lcos">
                    <img class="shape-6ZY3Vx" src="img/shape-22@1x.png" />
                    <img class="shape-oHWwqm" src="img/shape-26@1x.png" />
                    <img class="shape-Iclid4" src="img/shape-22@1x.png" />
                    <img class="shape-lxkVOF" src="img/shape-22@1x.png" />
                    <img class="shape-vFiprx" src="img/shape-22@1x.png" />
                  </div>
                  <div class="flex-col-sYXv4S">
                    <img class="shape-v1ujuj" src="img/shape-22@1x.png" />
                    <img class="shape-WmhAnJ" src="img/shape-26@1x.png" />
                    <img class="shape-8VWtg1" src="img/shape-22@1x.png" />
                    <img class="shape-pmSRie" src="img/shape-22@1x.png" />
                    <img class="shape-5H2T9s" src="img/shape-22@1x.png" />
                  </div>
                  <div class="flex-col-tML65g">
                    <img class="shape-Klqxxz" src="img/shape-22@1x.png" />
                    <img class="shape-aALoCW" src="img/shape-26@1x.png" />
                    <img class="shape-o6gduS" src="img/shape-22@1x.png" />
                    <img class="shape-b0V7Vl" src="img/shape-22@1x.png" />
                    <img class="shape-46yfni" src="img/shape-22@1x.png" />
                  </div>
                </div>
                <img class="path-486fCs" src="img/path-81@1x.png" />
                <img class="path-I6CGAw" src="img/path-82@1x.png" />
                <img class="path-x023y0" src="img/path-83@1x.png" />
                <div class="group-8oxvUO">
                  <div class="overlap-group5-dBwEjx">
                    <img class="path-VSNfTn" src="img/path-247@1x.png" />
                    <img class="path-C0tQfj" src="img/path-248@1x.png" />
                  </div>
                  <img class="path-dBwEjx" src="img/path-250@1x.png" />
                  <img class="path-4fo2M0" src="img/path-249@1x.png" />
                </div>
                <img class="group-2ifDBY" src="img/group-2@1x.png" />
                <img class="path-n7RHNx" src="img/path-84@1x.png" />
                <img class="group-NM3VPy" src="img/group-3@1x.png" />
                <div class="oval-486fCs"></div>
                <div class="group-xkIIeO">
                  <img class="path-YdvIWg" src="img/path-251@1x.png" />
                  <img class="path-fuE4vu" src="img/path-252@1x.png" />
                  <div class="group-YdvIWg">
                    <img class="path-SV2Syh" src="img/path-254@1x.png" />
                    <img class="path-wPj5Xu" src="img/path-255@1x.png" />
                    <img class="path-XaeswL" src="img/path-256@1x.png" />
                    <img class="path-NKYHoq" src="img/path-257@1x.png" />
                  </div>
                  <img class="path-6cvfo1" src="img/path-253@1x.png" />
                </div>
                <img class="path-8oxvUO" src="img/path-247@1x.png" />
                <img class="path-2ifDBY" src="img/path-248@1x.png" />
                <img class="path-NM3VPy" src="img/path-87@1x.png" />
                <img class="path-xkIIeO" src="img/path-88@1x.png" />
                <div class="oval-I6CGAw"></div>
                <div class="group-WkErfz">
                  <img class="path-RMTrT9" src="img/path-251@1x.png" />
                  <img class="path-NvHziv" src="img/path-252@1x.png" />
                  <div class="group-RMTrT9">
                    <img class="path-tyc6Jx" src="img/path-254@1x.png" />
                    <img class="path-D7kxMl" src="img/path-255@1x.png" />
                    <img class="path-xLUDm3" src="img/path-256@1x.png" />
                    <img class="path-sHrhIT" src="img/path-257@1x.png" />
                  </div>
                  <img class="path-xpVnSU" src="img/path-253@1x.png" />
                </div>
              </div></div
          ></a>
        </div>
        <div class="overlap-group1-C61RwL">
          
          <div class="am-furniture-RH0WJ5 arial-bold-black-16px">Copyright © A&M 2019</div>
        </div>
      </div>
    </div>
</body>
</html>