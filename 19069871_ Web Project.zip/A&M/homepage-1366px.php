
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, intial-scale=1.0" />
    <link rel="shortcut icon" type=""  />
    <meta name="og:type" content="website" />
    <meta name="twitter:card" content="photo" />
    <link rel="stylesheet" type="text/css" href="css/homepage-1366px.css" />
    <link rel="stylesheet" type="text/css" href="css/styleguide.css" />
    <link rel="stylesheet" type="text/css" href="css/globals.css" />
	
    <link rel="stylesheet" href="static/css/chat.css">
    <link rel="stylesheet" href="static/css/home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body style="margin: 0; background: #ffffff">
    <input type="hidden" id="anPageName" name="page" value="homepage-1366px" />
    <div class="container-center-horizontal">
      <div class="homepage-1366px screen">
        <div class="rectangle-1118-C61RwL"></div>
        <div class="rectangle-1114-C61RwL border-2px-cream-can"></div>
        <div class="rectangle-1115-C61RwL border-2px-cream-can"></div>
        <div class="rectangle-1117-C61RwL border-2px-cream-can"></div>
        <img class="path-209-C61RwL" src="img/path-209@1x.png" />
        <div class="rectangle-1109-C61RwL"></div>
        <div class="rectangle-1110-C61RwL"></div>
        <img
          class="modern-stylish-hen-accessories-C61RwL"
          src="img/modern-stylish-scandinavian-kitchen-interior-with-kitchen-access@1x.png"
        />
        <img
          class="realistic-moder-rame176382-411-C61RwL"
          src="img/realistic-modern-double-bedroom-with-furniture-frame-176382-411@1x.png"
        />
        <img
          class="modern-living-r-wall-background-C61RwL"
          src="img/modern-living-room-interior-with-sofa-green-plants-lamp-table-da@1x.png"
        />
        <div class="rectangle-1111-C61RwL"></div>
        <div class="rectangle-1112-C61RwL"></div>
        <div class="rectangle-1113-C61RwL"></div>
        <div class="rectangle-1102-C61RwL"></div>
        <img class="path-210-C61RwL" src="img/path-210@1x.png" />
        <img class="path-211-C61RwL" src="img/path-211@1x.png" />
		<a href= "#iText" ><div class="clearance-deals-C61RwL arial-bold-bush-16px">Clearance deals</div></a>
        
        <a href= "#Txt" ><div class="contact-us-C61RwL arial-bold-bush-16px">Contact us</div></a>
        <div class="x-C61RwL"></div>
		<a href = "#iTm">
        <div class="new-arrivals-C61RwL arial-bold-bush-16px">New Arrivals</div></a>
        <img class="luxury-classic-oom-suite-hotel-C61RwL" src="img/luxury-classic-modern-bedroom-suite-hotel@1x.png" />
        
		<div class="new-in-store-C61RwL arial-bold-bush-32px" id="iTm">NEW IN-STORE</div>
        <div class="group-5-C61RwL border-2px-cream-can">
          <div class="shop-by-rooms-iZjIT4 arial-bold-bush-32px">SHOP BY ROOMS</div>
        </div>
        <div class="living-room-C61RwL arial-bold-bush-25px">Living Room</div>
        <div class="kitchen-dining-C61RwL arial-bold-bush-25px">Kitchen &amp; Dining</div>
        <div class="bedroom-C61RwL arial-bold-bush-25px">Bedroom</div>
        <div class="inspiration-ideas-C61RwL arial-bold-bush-32px">INSPIRATION IDEAS</div>
        <div class="clearance-deal-C61RwL arial-bold-bush-32px" id="iText">Clearance Deal</div>
        <a href="artboard-1.php"><div class="sign-up-C61RwL arial-bold-bush-16px">Sign up</div></a>
        <div class="footer-1-C61RwL">
          <div class="contact-us-rXXfIu arial-bold-bush-16px" id="Txt" >CONTACT US</div>
          <p class="x44-345-678-903a-comfind-a-store-rXXfIu arial-regular-normal-bush-14px">
            +44 345 678 903<br />a&m@mail.com<br />Find a Store
          </p>
          <div class="services-rXXfIu arial-bold-bush-16px">SERVICES</div>
          <p class="contact-usorder-faqsizing-guide-rXXfIu arial-regular-normal-bush-14px">
            Contact Us<br />Ordering &amp; Payment<br />Shipping<br />Returns<br />FAQ<br />Sizing Guide
          </p>
          <div class="information-rXXfIu arial-bold-bush-16px">INFORMATION</div>
          <p class="about-maynooth-press-enquiries-rXXfIu arial-regular-normal-bush-14px">
            About<br />Work With US<br />Privacy Policy<br />Terms &amp; Conditions<br />Press
            Enquiries
          </p>
          <div class="flex-col-rXXfIu">
            <div class="social-PSiDd1">
              <div class="symbol-13-1-OlyBTy"></div>
              <div class="symbol-12-1-OlyBTy"><img class="path-2-YsM9lK" src="img/path-2@1x.png" /></div>
              <div class="symbol-11-1-OlyBTy"><img class="path-1-rwUcqh" src="img/path-1@1x.png" /></div>
            </div>
            <div class="maynooth-furniture-PSiDd1 arial-bold-bush-16px"></div>
          </div>
        </div>
        <div class="radio-buttons-C61RwL">
          <div class="rectangle-662-Vmy2mJ border-3px-desert-storm"></div>
          <div class="rectangle-663-Vmy2mJ border-3px-desert-storm"></div>
          <div class="overlap-group-Vmy2mJ">
            <div class="rectangle-664-4kaw9V border-3px-desert-storm"></div>
            <div class="rectangle-666-4kaw9V"></div>
          </div>
        </div>
        <div class="radio-buttons-VMr6Om">
          <div class="rectangle-662-ZvSJw7 border-3px-bush"></div>
          <div class="overlap-group1-ZvSJw7">
            <div class="rectangle-663-RSQbpB border-3px-bush"></div>
            <div class="rectangle-666-RSQbpB"></div>
          </div>
          <div class="rectangle-664-ZvSJw7 border-3px-bush"></div>
        </div>
        <div class="radio-buttons-mzXdH9">
          <div class="rectangle-662-HW7EPG border-3px-bush-2"></div>
          <div class="overlap-group2-HW7EPG">
            <div class="rectangle-663-y8oQxX border-3px-bush-2"></div>
            <div class="rectangle-666-y8oQxX"></div>
          </div>
          <div class="rectangle-664-HW7EPG border-3px-bush-2"></div>
        </div>
        <div class="radio-buttons-QxM5SU">
          <div class="rectangle-662-OwKswN border-3px-bush"></div>
          <div class="overlap-group3-OwKswN">
            <div class="rectangle-663-QFzL5V border-3px-bush"></div>
            <div class="rectangle-666-QFzL5V"></div>
          </div>
          <div class="rectangle-664-OwKswN border-3px-bush"></div>
        </div>
		

       <a href="successfullogin.html">
	   <div class="profile-C61RwL"></div></a>
		<div class="group-31-C61RwL">
         <a href="Cart.php"><div class="group-9-I5cRPp"></div></a>
        </div>
        
        <div class="backward-C61RwL border-2px-alice-blue">
          <div class="symbol-84-cc6iyG"><img class="path-36-bg94bJ" src="img/path-36-1@1x.png" /></div>
        </div>
        <div class="backward-VMr6Om border-2px-alice-blue">
          <div class="symbol-84-HHZO08"><img class="path-36-LL9877" src="img/path-36-1@1x.png" /></div>
        </div>
        <div class="backward-mzXdH9 border-2px-alice-blue">
          <div class="symbol-84-4BcGFw"><img class="path-36-v6jGCR" src="img/path-36-1@1x.png" /></div>
        </div>
        <div class="backward-QxM5SU border-2px-alice-blue">
          <div class="symbol-84-B5LDxo"><img class="path-36-4uZjQS" src="img/path-36-1@1x.png" /></div>
        </div>
        <div class="forward-C61RwL border-2px-alice-blue">
          <div class="symbol-85-9xgvyK"><img class="path-36-nGykOa" src="img/path-36-4@1x.png" /></div>
        </div>
        <div class="forward-VMr6Om border-2px-alice-blue">
          <div class="symbol-85-BzeExO"><img class="path-36-pYC00Z" src="img/path-36-4@1x.png" /></div>
        </div>
        <div class="forward-mzXdH9">
          <div class="group-45-IxcKbr">
            <div class="group-44-LuQ8Ee border-2px-alice-blue"></div>
            <div class="symbol-85-LuQ8Ee"><img class="path-36-IxxesJ" src="img/path-36-4@1x.png" /></div>
          </div>
          <div class="group-46-IxcKbr">
            <div class="symbol-85-HXPCKq"><img class="path-36-6tpZ1l" src="img/path-36-4@1x.png" /></div>
            <div class="rectangle-1072-HXPCKq border-2px-alice-blue"></div>
            <div class="group-44-HXPCKq border-2px-alice-blue"></div>
          </div>
          <div class="rectangle-1138-IxcKbr border-2px-alice-blue"></div>
        </div>
        <div class="forward-QxM5SU border-2px-alice-blue">
          <div class="symbol-85-H89wQu"><img class="path-36-48tCLP" src="img/path-36-4@1x.png" /></div>
        </div>
		
		
		

		
		
		
        <div class="crafted-withexcellence-C61RwL"><br />CRAFTED WITH<br /><br /><br />EXCELLENCE</div>
        <img class="icons8-star-64-C61RwL" src="img/icons8-star-64-10@1x.png" />
        <img class="icons8-star-64-VMr6Om" src="img/icons8-star-64-10@1x.png" />
        <img class="icons8-star-64-mzXdH9" src="img/icons8-star-64-10@1x.png" />
        <img class="icons8-star-64-QxM5SU" src="img/icons8-star-64-10@1x.png" />
        <img class="icons8-star-64-2P4qUJ" src="img/icons8-star-64-14@1x.png" />
        <div class="group-7-C61RwL">
          <img class="icons8-star-64-SO40Oe" src="img/icons8-star-64-10@1x.png" />
          <img class="icons8-star-64-Uh8Hn6" src="img/icons8-star-64-10@1x.png" />
          <img class="icons8-star-64-Og4NVI" src="img/icons8-star-64-10@1x.png" />
          <img class="icons8-star-64-0OBBZZ" src="img/icons8-star-64-13@1x.png" />
          <img class="icons8-star-64-l7ws9x" src="img/icons8-star-64-14@1x.png" />
        </div>
        <div class="group-8-C61RwL">
          <img class="icons8-star-64-3cZhlu" src="img/icons8-star-64-10@1x.png" />
          <img class="icons8-star-64-8v7f9Z" src="img/icons8-star-64-10@1x.png" />
          <img class="icons8-star-64-aX2jdN" src="img/icons8-star-64-10@1x.png" />
          <img class="icons8-star-64-BIx5Oq" src="img/icons8-star-64-13@1x.png" />
          <img class="icons8-star-64-nlyzpw" src="img/icons8-star-64-14@1x.png" />
        </div>
        <img
          class="discount-sale-p-sign1017-15624-C61RwL"
          src="img/discount-sale-price-tag-design-1017-15624-1@1x.png"
        />
        <img
          class="discount-sale-p-sign1017-15624-VMr6Om"
          src="img/discount-sale-price-tag-design-1017-15624-1@1x.png"
        />
        <img
          class="discount-sale-p-sign1017-15624-mzXdH9"
          src="img/discount-sale-price-tag-design-1017-15624-1@1x.png"
        />
        <div class="vintage-collection-C61RwL">VINTAGE COLLECTION</div>
        <div class="hand-crafted-C61RwL">HAND CRAFTED</div>
        <div class="vintage-arm-chair-C61RwL arial-bold-bush-16px">Vintage Arm chair</div>
        <div class="vintage-luxury-sofa-C61RwL arial-bold-bush-16px">Vintage Luxury sofa</div>
        <div class="vintage-sofa-C61RwL arial-bold-bush-16px">Vintage Sofa</div>
        <div class="x3560-rm-C61RwL arial-regular-normal-dove-gray-16px">3560 RM</div>
        <div class="x4650-rm-C61RwL arial-regular-normal-dove-gray-16px">4650 RM</div>
        <div class="x7850-rm-C61RwL arial-regular-normal-dove-gray-16px">7850 RM</div>
        <div class="x1560-rm-C61RwL arial-bold-bush-16px">1560 RM</div>
        <div class="x1560-rm-VMr6Om arial-bold-bush-16px">1560 RM</div>
        <div class="x1560-rm-mzXdH9 arial-bold-bush-16px">1560 RM</div>
        <div class="ellipse-6-C61RwL border-1px-cream-can"></div>
        <div class="ellipse-7-C61RwL border-1px-cream-can"></div>
        <div class="ellipse-8-C61RwL border-1px-cream-can"></div>
		
		       
        <img
          class="kisspng-coffee-715209553201729-C61RwL"
          src="img/kisspng-coffee-table-nightstand-dining-room-matbord-hd-creative-@1x.png"
        />
		<img
          class="kisspng-eames-l-981517605959661-C61RwL"
          src="img/kisspng-eames-lounge-chair-table-furniture-armchair-child-5a74d4@1x.png"
        />
        <img
          class="kisspng-wing-ch-615170915613702-C61RwL"
          src="img/kisspng-wing-chair-furniture-couch-ornate-chair-5a6cfae95a6349-5@1x.png"
        />
        <img
          class="kisspng-furnitu-115196569878727-C61RwL"
          src="img/kisspng-furniture-poster-couch-home-furnishings-5a94201bd51107-0@1x.png"
        />
        <img class="x5a1d0c514903535-615118531372991-C61RwL" src="img/5a1d0c51490353-5739409615118531372991@1x.png" />
        <img
          class="kisspng-couch-m-815181603858127-C61RwL"
          src="img/kisspng-couch-mid-century-modern-table-sofa-bed-furniture-a-sofa@1x.png"
        />
        <img
          class="kisspng-the-cha-415255496311891-C61RwL"
          src="img/kisspng-the-chair-king-inc-throne-garden-furniture-antique-furni@1x.png"
        />
        <img
          class="kisspng-window-115193511477643-C61RwL"
          src="img/kisspng-window-living-room-curtain-couch-furniture-american-simp@1x.png"
        />
		 
		 <form method="post" action="shoppingcart3.php?action=add&id=<?php echo $row["id"]; ?>">
		 <div class="group-18-C61RwL">
          
          <button type="submit" class="group-14-0xverS"></button>
		  </div>
		</form>
		
		<form method="post" action="shoppingcart4.php?action=add&id=<?php echo $row["id"]; ?>">
          <div class="group-17-C61RwL">
          
	
          <button type="submit" class="group-15-B2GfxI"></button>
        </div>
		</form>
		
		<form method="post" action="shoppingcart5.php?action=add&id=<?php echo $row["id"]; ?>">
        <div class="group-19-C61RwL">
         
          <button type="submit" class="group-16-ebBR7z"></button>
        </div>
		</form>
		
		
        <div class="group-20-C61RwL">
		<form method="post" action="wishlist.php?action=add&id=<?php echo $row["id"]; ?>">
     
		  </form>
		  <form method="post" action="shoppingcart.php?action=add&id=<?php echo $row["id"]; ?>">
          <button type="submit" class="group-15-IE4p6q"></button>
        </div>
		</form>
		
		<form method="post" action="shoppingcart2.php?action=add&id=<?php echo $row["id"]; ?>">
        <div class="group-21-C61RwL">
         
          <button type="submit" class="group-15-8x0eH3"></button>
        </div>
		</form>
		
		<form method="post" action="shoppingcart6.php?action=add&id=<?php echo $row["id"]; ?>">
        <div class="group-22-C61RwL">
         
          <button type="submit" class="group-15-VdQhAS"></button>
        </div>
		</form>
		
        <p class="created-with-ex-supreme-quality-C61RwL">Created with excellence and supreme quality</p>
        <div class="rectangle-1121-C61RwL"></div>
        <div class="rectangle-1122-C61RwL"></div>
        <div class="rectangle-1123-C61RwL"></div>
       <div class="chat-bar-collapsible">
        <button id="chat-button" type="button" class="collapsible">Chat with Us!
            <i id="chat-icon" style="color: #fff;" class="fa fa-fw fa-comments-o"></i>
        </button>

        <div class="content">
            <div class="full-chat-block">
                <!-- Message Container -->
                <div class="outer-container">
                    <div class="chat-container">
                        <!-- Messages -->
                        <div id="chatbox">
                            <h5 id="chat-timestamp"></h5>
                            <p id="botStarterMessage" class="botText"><span>Loading...</span></p>
                        </div>

                        <!-- User input box -->
                        <div class="chat-bar-input-block">
                            <div id="userInput">
                                <input id="textInput" class="input-box" type="text" name="msg"
                                    placeholder="Tap 'Enter' to send a message">
                                <p></p>
                            </div>

                            <div class="chat-bar-icons">
                                <i id="chat-icon" style="color: crimson;" class="fa fa-fw fa-heart"
                                    onclick="heartButton()"></i>
                                <i id="chat-icon" style="color: #333;" class="fa fa-fw fa-send"
		
                                    onclick="sendButton()"></i>
                            </div>
                        </div>

                        <div id="chat-bar-bottom">
                            <p></p>
                        </div>


                    </div>
                </div>

            </div>
        </div>

    </div>
		
        
        <div class="group-27-C61RwL">
          <div class="group-3-BKbGut">
            <img class="rectangle-1097-yng7RT" src="img/rectangle-1097@1x.png" />
            <img class="rectangle-1098-yng7RT" src="img/rectangle-1097-1@1x.png" />
            <img class="rectangle-1099-yng7RT" src="img/rectangle-1099-1@1x.png" />
            <img class="rectangle-1100-yng7RT" src="img/rectangle-1100-1@1x.png" />
            <div class="rectangle-1101-yng7RT"></div>
          </div>
          <h1 style= "font-family: Lucida Console, Courier New, monospace" class="title-BKbGut poorrichard-regular-normal-bush-65px">A&amp;M</h1></style>
        </div>
        <div class="arrowupwardblack24dp-C61RwL"><img class="path-219-tCWjEg" src="img/path-219@1x.png" /></div>
        <div class="arrowupwardblack24dp-VMr6Om"><img class="path-219-SKbcxu" src="img/path-219-1@1x.png" /></div>
        <div class="arrowupwardblack24dp-mzXdH9"><img class="path-220-2Gs290" src="img/path-220@1x.png" /></div>
      </div>
    </div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="static/scripts/responses.js"></script>
<script src="static/scripts/chat.js"></script>

  </body>
</html>
