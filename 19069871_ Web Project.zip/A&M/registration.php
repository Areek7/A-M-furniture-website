<?php

session_start();
$host="localhost";
$user="android";
$pass="mypasswd";
$db="robots";

$conn = mysqli_connect($host,$user,$pass,$db);

if ($conn->connect_error){
	die();
}

function mysql_fatal_error($message)
{
		echo "error";
		/*
	 We are sorry, but it was not possible to complete
	 the requested task. The error message we got was:
	           <p> Fatal Error</p>
    Please click the back button on the browser
	and try again. If you are still having problems,please
	<a href= "a&m:admin@server.com"> email our administrator</a>. 
	Thank You
	
		_END;*/
}
	

?>