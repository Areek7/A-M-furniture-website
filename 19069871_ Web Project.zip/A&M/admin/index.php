<?php 
include('header.php');
if(isset($_SESSION['ROLE']) && $_SESSION['ROLE']!='1'){
	header('location:enquiry.php');
	die();
}
?>
<div class="container-fluid">
<ol class="breadcrumb">
  <li class="breadcrumb-item">
	 <a href="../homepage-1366px.php">Home Page</a>
  </li>
</ol>
<!-- Page Content -->
<h1>Welcome to Admin Panel</h1>
<hr>
<ul> 
<a href= "../Cart.php ">       <li>Manage Cart</li></a>
<a href="../shoppingcart5.php"><li>Add Vintage Sofa</li></a>
 <a href="../shoppingcart3.php"><li>Add Vintage Arm chair</li></a>
<a href= "../shoppingcart4.php"><li>Add Vintage Luxury Sofa</li></a>
         <br></ul>
</div>
<?php include('footer.php')?>