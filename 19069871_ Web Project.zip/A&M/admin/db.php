<?php
$con=mysqli_connect('localhost','android','mypasswd','robots');
?>