<?php include('header.php')?>		 
<div class="container-fluid">
   <!-- DataTables Example -->
   <div class="card mb-3">
	  <div class="card-header">
		 <i class="fa fa-fw fa-newspaper"></i>
		 News Table
	  </div>
	  <div class="card-body">
		 <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
			   <thead>
				  <tr>
					 <th>Email</th>
					 <th>Enquiry</th>
					 <th>Date</th>
				  </tr>
			   </thead>
			   <tfoot>
				  <tr>
					 <th>Email</th>
					 <th>Enquiry</th>
					 <th>Date</th>
				  </tr>
			   </tfoot>
			   <tbody>
				  <tr>
					 <td>vikram1@gmail.com</td>
					 <td>Hi, I am Vikram and I would like to know when will be the next shipment for vintage sofa?</td>
					 <td>12th Sep 2019</td>
				  </tr>
				  <tr>
					 <td>satish7@gmail.com</td>
					 <td>Hi, Satish here and I am extremetly satisfies with the product of A&M furniture. I would like to know if I can customize my furniture?</td>
					 <td>14th Sep 2019</td>
				  </tr>
			   </tbody>
			</table>
		 </div>
	  </div>
   </div>
</div>
<!-- /.container-fluid -->
<?php include('footer.php')?>