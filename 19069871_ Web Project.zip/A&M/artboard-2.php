<?php
    session_start();
	
	require_once 'registration.php';
    if(isset($_POST['submit'])){
		$email =  mysqli_real_escape_string($conn, $_POST['email']);
		$email = filter_var($email, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
		$password = mysqli_real_escape_string($conn, $_POST['password']);
		$password = filter_var($password, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
		
		$email_search = "SELECT * FROM userdb WHERE email = '$email' ";
		$result = $conn->query($email_search);
		
		$email_count = mysqli_num_rows($result);
		print($email_count);
		
		if($email_count){
			$row = $result -> fetch_assoc();
			
			$db_pass = $row["password"];
			
			$pass_decode = password_verify($password, $db_pass); 
			
			if($pass_decode){
				echo "login successful";
				header('location:successfullogin.html');
			}else{
				echo "Password Incorrect";
			}
		}
		
				
		else{
			echo "Invalid Email";
		}
		
	}
?>
	

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=1920, maximum-scale=1.0" />
    <link rel="shortcut icon" type="image/png" />
    <meta name="og:type" content="website" />
    <meta name="twitter:card" content="photo" />
    <link rel="stylesheet" type="text/css" href="css/artboard-2.css" />
    <link rel="stylesheet" type="text/css" href="css/styleguide.css" />
    <link rel="stylesheet" type="text/css" href="css/globals.css" />
	
   
  </head>
  <style>
		
		.error{
			display: none;
			margin-left: 10px;
		}		
		
		.error_show{
			color: red;
			margin-left: 10px;
		}
		
		input.invalid, textarea.invalid{
			border: 2px solid red;
		}
		
		input.valid, textarea.valid{
			border: 2px solid green;
		}
	</style>
  
 
  
  <script>
		$(document).ready(function() {
		
				
				<!--Email must be an email -->
				$('#u_email').on('input', function() {
					var input=$(this);
					var re = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
					var is_email=re.test(input.val());
					if(is_email){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				
			
				$('#u_pass').on('input', function() {
					var input=$(this);
					var re = /((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,})$/;
					var is_pass=re.test(input.val());
					if(is_pass){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				
				
				
		
			<!-- After Form Submitted Validation-->
			$("#user_submit button").click(function(event){
				var form_data=$("#user").serializeArray();
				var error_free=true;
				for (var input in form_data){
					var element=$("#user_"+form_data[input]['name']);
					var valid=element.hasClass("valid");
					var error_element=$("span", element.parent());
					if (!valid){error_element.removeClass("error").addClass("error_show"); error_free=false;}
					else{error_element.removeClass("error_show").addClass("error");}
				}
				if (!error_free){
					event.preventDefault(); 
				}
				else{
					alert('No errors: Form will be submitted');
				}
			});
			
			
			
		});
	</script>
	
	
  <body style="margin: 0; background: #ffffff">
    <input type="hidden" id="anPageName" name="page" value="artboard-2" />
    <div class="container-center-horizontal">
      <div class="artboard-2 screen" >
        <div class="overlap-group1-C61RwL">
          <img class="base-RH0WJ5" src="img/base-1@1x.png" />
          
          <div class="group-29-RH0WJ5">
            <div class="group-3-MPsr4w">
              <img class="rectangle-1097-sMvump" src="img/rectangle-1097-1@1x.png" />
              <img class="rectangle-1098-sMvump" src="img/rectangle-1097-1@1x.png" />
              <img class="rectangle-1099-sMvump" src="img/rectangle-1099-1@1x.png" />
              <img class="rectangle-1100-sMvump" src="img/rectangle-1100-1@1x.png" />
              <div class="rectangle-1101-sMvump"></div>
            </div>
            <div style= "font-family: Lucida Console, Courier New, monospace" class="am-MPsr4w poorrichard-regular-normal-bush-65px">A&amp;M</div></style>
          </div>
          <div class="group-31-RH0WJ5">
           
          </div>
        </div>
        <div class="overlap-group-C61RwL">
          <div class="rectangle-1124-4eduM0"></div>
		  
		  <form method = "POST" action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>"
		  <form>
          <div class="form-4eduM0">
            <input class="email-rxMhoe" style="font-family: Futura, 'Trebuchet MS', Arial, sans-serif; font-size: 24px;text-align: center;font-weight: bold;display: block;" id = "u_email" type="email" name="email" placeholder= "Enter Your Email" required>
            <span class="error">This field is required</span>
			<div>
            <input class="company-rxMhoe" style="font-family: Futura, 'Trebuchet MS', Arial, sans-serif; font-size: 24px;text-align: center;font-weight: bold;display: block;" id = "u_pass" type="password"  name="password" placeholder= "Enter Your Password" required></div>
            <span class="error">This field is required</span>
		  </div>
          <div class="log-in-4eduM0 arial-bold-bush-40px">Log in</div>
          <div class="group-32-4eduM0">
		  
            <div ></div>

			<input type ="submit" name="submit" value="Sign In" class="company-HrL9om"/>
          </div>
		  </form>
          <div class="transportation-ooter-happy-man-4eduM0">
            <div class="group-5jYDGz">
              <div class="group-BRGp96">
                <img class="path-v0QR59" src="img/path-340@1x.png" />
                <img class="path-K5widr" src="img/path-341@1x.png" />
                <img class="group-v0QR59" src="img/group-6@1x.png" />
              </div>
              <img class="path-BRGp96" src="img/path-329@1x.png" />
              <img class="path-PCD8ar" src="img/path-330@1x.png" />
              <img class="path-wDK0AG" src="img/path-331@1x.png" />
              <img class="path-njWBav" src="img/path-332@1x.png" />
              <img class="path-t4shiv" src="img/path-333@1x.png" />
              <img class="path-bcdQJ3" src="img/path-334@1x.png" />
              <div class="group-PCD8ar">
                <img class="path-MbA3ry" src="img/path-348@1x.png" />
                <div class="overlap-group3-MbA3ry">
                  <img class="path-takmKz" src="img/path-343@1x.png" />
                  <img class="path-MhnEgB" src="img/path-344@1x.png" />
                  <img class="path-c2CqSq" src="img/path-345@1x.png" />
                  <img class="path-CTBXFB" src="img/path-346@1x.png" />
                  <img class="path-Y2RTwG" src="img/path-347@1x.png" />
                </div>
                <img class="path-iO9JZe" src="img/path-342@1x.png" />
              </div>
              <div class="oval-BRGp96"></div>
              <div class="oval-PCD8ar"></div>
              <div class="oval-wDK0AG"></div>
              <img class="path-AqOHg0" src="img/path-335@1x.png" />
              <div class="group-wDK0AG">
                <img class="path-mo64HP" src="img/path-349@1x.png" />
                <img class="path-MnTxN7" src="img/path-350@1x.png" />
                <img class="path-7dnv4z" src="img/path-351@1x.png" />
              </div>
              <img class="oval-njWBav" src="img/oval@1x.png" />
              <img class="path-EW1qdf" src="img/path-336@1x.png" />
              <img class="path-PvWJ8q" src="img/path-337@1x.png" />
              <img class="group-njWBav" src="img/group-7@1x.png" />
              <div class="oval-t4shiv"></div>
              <div class="oval-bcdQJ3"></div>
              <img class="path-nxC4tS" src="img/path-338@1x.png" />
              <img class="path-aHfZFe" src="img/path-339@1x.png" />
              <div class="group-t4shiv">
                <img class="path-GNcFsW" src="img/path-356@1x.png" />
                <img class="path-3calmF" src="img/path-352@1x.png" />
                <div class="flex-col-GNcFsW">
                  <img class="path-kregrD" src="img/path-357@1x.png" />
                  <img class="path-K5oc6n" src="img/path-353@1x.png" />
                </div>
                <img class="path-gSSxKZ" src="img/path-354@1x.png" />
                <img class="path-4eBcF5" src="img/path-353@1x.png" />
              </div>
            </div>
          </div>
      <div class="forgot-password-4eduM0 ">Don't Have Account? &nbsp <span><a href= "artboard-1.php">Sign Up <a/></span></div>
        </div>
		
        
      </div>
    </div>
	    <script type="text/javascript" src="./vendors/jquery-3.3.1/jquery-3.3.1.min.js"></script>
        <script type="text/javascript" src="./vendors/bootstrap-3.4.1/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="./vendors/moment-2.24.0/moment-with-locales.min.js"></script>
        <script type="text/javascript" src="../dist/jquery.niceform.js"></script>
        <script type="text/javascript" src="./js/examples.js"></script>
  </body>
</html>
