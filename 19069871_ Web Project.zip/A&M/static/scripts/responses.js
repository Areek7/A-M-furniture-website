function getBotResponse(input) {
    
    if (input == "I love A&M Furniture!") {
        return "Glad you had a wonderful experience!";
    } else if (input == "Hello") {
        return "Hi, How are you doing today?";
    } else if (input == "furniture") {
        return "Email: a&m@mail.com";
    }


    // Simple responses
    if (input == "") {
        return "Hi, How are you doing today?";
    } else if (input == "goodbye") {
        return "Talk to you later!";
    } else {
        return "Email: a&m@mail.com";
    }

}