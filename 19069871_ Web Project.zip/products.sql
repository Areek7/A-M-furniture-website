-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 16, 2021 at 03:17 PM
-- Server version: 8.0.18
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `products`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`id`, `name`, `code`, `image`, `price`) VALUES
(1, 'Red King chair', '3DcAM01', 'img/kisspng-the-chair-king-inc-throne-garden-furniture-antique-furni@1x.png', 2000.00),
(2, 'Lounge Arm Chair', 'USB02', 'img/kisspng-eames-lounge-chair-table-furniture-armchair-child-5a74d4@1x.png', 1200.00),
(3, 'Vintage Arm Chair', 'ARMCHA04', 'img/kisspng-wing-chair-furniture-couch-ornate-chair-5a6cfae95a6349-5@1x.png', 1560.00),
(4, 'Vintage Luxury Sofa', 'LPN45', 'img/kisspng-furniture-poster-couch-home-furnishings-5a94201bd51107-0@1x.png', 1700.00),
(5, 'Vintage  Sofa', 'VTN45', 'img/5a1d0c51490353-5739409615118531372991@1x.png', 1560.00),
(6, 'Coffee Table', 'CAFE89', 'img/kisspng-coffee-table-nightstand-dining-room-matbord-hd-creative-@1x.png', 1000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_code` (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblproduct`
--
ALTER TABLE `tblproduct`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
